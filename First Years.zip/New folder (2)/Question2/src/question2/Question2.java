/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package question2;

/**
 *
 * @author Lenovo
 */
public class Question2 {

    /**
     * @param args the command line arguments
     */
   public static String place[] = {"Flat","Town House","House"};
 public static String province[] = {"Gauteng","Natal","Cape",};
 public static int re[][] ={{800000,1500000,2000000},{700000,1200000,1600000},{7500000,1300000,1800000}};
  public static double total[] = new double[3];
 public static double tota[] = new double[3];
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println(
              "\t\t\t"+ place[0] + "\t\t"+  place[1] + "\t\t"+  place[2] + "\t\t"
                +
           "\n***************************************************************************************\n"
               );
        
        double count = 0;
        double  cou = 0;
        for (int i = 0; i < re.length; i++) {
            count = 0;
            cou= 0;
            System.out.print(province[i] + ": --->\t" + "" );
             for (int x = 0; x < re[i].length; x++) {
                System.out.print("R "+re[i][x] + "\t\t");
               count += re[i][x];
                cou+= re[x][i];
            }
             total[i] = count/3;
             tota[i]= cou;
             
            System.out.println("");
        }
           
        System.out.println("");
                for (int i = 0; i < province.length; i++) {
                    
                     System.out.print("Average property prices in " + province[i]+ " = \t" +"R"
                             
                             + Math.round(total[i])  + "\t" + "\n");
        }
         
      
    }
   
}

