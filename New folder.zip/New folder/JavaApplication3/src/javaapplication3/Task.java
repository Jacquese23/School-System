/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication3;

/**
 *
 * @author Lenovo
 */
 

import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.*;

public class Task {
    public static  Scanner read = new Scanner(System.in);
   public static ArrayList<String>names = new ArrayList<>();
  public static ArrayList<Integer>cou = new ArrayList<>();
   public static ArrayList<String>tass = new ArrayList<>();
   public static ArrayList<String>dev = new ArrayList<>();
   public static ArrayList<String>lasts = new ArrayList<>();
   public static ArrayList<String>desc = new ArrayList<>();
   public static ArrayList<Double>durat = new ArrayList<>();
     public static String name;
    public void tasks(){
        int counter=0;
        cou.add(counter);
        System.out.println("\n********************New Task*******************");
         System.out.println("Please the task name");
         String taskn= read.nextLine();
         tass.add(taskn);
          System.out.println("Please enter the developers First name");
        String last =read.nextLine();       
      String lastlet= last.substring(last.length()-3,last.length());
      lasts.add(lastlet);
         System.out.println("Please the description below 50 characters");
         String des = read.nextLine();
         desc.add(des);
        int count=0;
        for (int i = 0; i <des.length(); i++) {
            if(des.charAt(i)!=' '){
         while(count<50){
             count++;
             
          if(count>50){
           System.out.println("Task is above 50 characters");
           break;
          }
         }
        }
        }
        System.out.println(" Task has been successful been captured");
        System.out.println("Please enter the duration of the task");
        String dura = read.nextLine();
        
        double dur= Double.parseDouble(dura);
         durat.add(dur);
     
        System.out.println("Please enter your First and Last name");
         name.toUpperCase();
        name = read.nextLine();
        
        names.add(name);
       split(name);
       System.out.print(":" + counter +":" + lastlet.toUpperCase());
        JOptionPane.showMessageDialog(null,"*************Overview**************\n"
                + "Task name : " + taskn 
                + "\nDescription: "+ des 
                + "\nDeveloper name: " + last
                + "\nDuration: " + dur 
        );
        read.nextLine();
      
       System.out.println("Would you like to continue? Press 1 to Continue or 2 to exit or 3 to view all items in array");
       String anss =read.nextLine();
       switch(anss){
                      case "1":
                          counter+=1;
                          tasks();
                          break;
                       case "2":
                           System.exit(0);
                          break;
                           case "3":
                               for(int i = 0; i < tass.size(); i++) {   
    System.out.println(tass.get(i) +dev.get(i)   
            +names.get(i) +desc.get(i)+ durat.get(i) +lasts.get(i)+ cou.get(i) );
                                   System.out.println("");
                               }
                           
                          break;
                          }
    }public void split(String name){
    String words[] = name.split(" ");
            for (int i = 0; i < words.length; i++) {
                String spli = words[i];
                System.out.print(spli.charAt(0));         
            }
    
    
    }
    
}
