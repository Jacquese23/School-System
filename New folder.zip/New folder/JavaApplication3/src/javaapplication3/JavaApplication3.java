/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication3;
import java.util.*;
/**
 *
 * @author Lenovo
 */
public class JavaApplication3 {

    /**
     * @param args the command line arguments
     */
    public static String answer;
    public static Task ne = new Task();
     public static  Scanner read = new Scanner(System.in);
    public static void main(String[] args) {
        System.out.println("**************************\nWelcome to EasyKanban\n**************************\n"
                + "1) Add tasks Option \n2) Show report  \n3) Quit");
                  answer = read.nextLine();
                  switch(answer){
                      case "1":
                          ne.tasks();
                          break;
                       case "2":
                           System.out.println(" Coming soon-System is still under development ");
                          break;
                          case "3":
                              System.exit(0);
                          break;
                  
                  }
    }
    
}
