using System;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;
using System.Data;

namespace ClassLibrary
{
    public class Class1
    {

       
        public string ModuleCode { get; set; }
        public int ClassHours { get; set; }
        public int Studyhours { get; set; }
        public string ModuleName { get; set; }
        public int Credits { get; set; }
        public int Semesterweeks { get; set; }



        public Class1(string ModuleCode, string ModuleName, int Classhours, int StudyHours, int Credits, int Semesterweeks)
        {
            this.ModuleCode = ModuleCode;
            this.ClassHours = Classhours;
            this.Studyhours = StudyHours;
            this.ModuleName = ModuleName;
            this.Credits = Credits;
            this.Semesterweeks = Semesterweeks;


        }

        public double week = 0;
        public double remain = 0;
        public double Weekly()
        {

            double week = (Credits * 10) / (Semesterweeks - ClassHours * -1);
            return week;

        }

        /// Method to get a certain day
        /// </summary>

        public double RemainingHours()
        {
            double remain = Weekly() - Studyhours * -1;
            return remain;
        }
    



    public static string PasswordHashing(string password)
        {
            SHA1CryptoServiceProvider sHA1CryptoServiceProvider = new SHA1CryptoServiceProvider();
            byte[] passwordbyted = Encoding.ASCII.GetBytes(password);
            byte[] encrypted = sHA1CryptoServiceProvider.ComputeHash(passwordbyted);
            return Convert.ToBase64String(encrypted);
        }


       
    }
}
   

     



