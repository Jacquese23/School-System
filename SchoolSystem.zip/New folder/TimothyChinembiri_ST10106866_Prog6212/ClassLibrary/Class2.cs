﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{

    public class Class2
    {
        public SqlConnection conn = new SqlConnection("Data Source=DESKTOP-DJUTANK\\SQLEXPRESS;Initial Catalog=SchoolDatabaseSystem;Integrated Security=True");
    }
    }
