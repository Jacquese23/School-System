﻿using ClassLibrary;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace SchoolSystem_
{
    /// <summary>
    /// Interaction logic for StudentHub.xaml
    /// </summary>
    public partial class StudentHub : Window
    {
        public StudentHub()
        {
            InitializeComponent();

        }
        
        public List<Class1> cap = new List<Class1>();
        public String start, end;

        private void exitbtn1(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void Capturesbtn(object sender, RoutedEventArgs e)
        {

            try
            {
                Validate();
                 //variable
                string ModuleCode = Codebx.Text.ToString();
                string ModuleName = Namebx.Text;
                int Credit = Convert.ToInt32(Credits_.Text);
                int Semesterweek = Convert.ToInt32(semsterbx.Text);
                int ClassHour = Convert.ToInt32(hoursbx.Text);
                int Studyhours = Convert.ToInt32(hoursbx1.Text);

                Class1 get = new Class1 (ModuleCode, ModuleName, Credit, Semesterweek, ClassHour, Studyhours);
                cap.Add(get);
                start = Selectdate.Text.ToString();
                end = daydate.Text.ToString();
               
                
                var Query = from Information in cap select Information;
                foreach (var GetAll in Query)
                {
                   ///data from collection
                    ModuleList.Items.Add("\n ~*~*~*~*~*~*~*~*~*~*~*~*~*~~*~*~*~*~~*~*~*~*~*~*~*~~*~*\n" +
                                          " Module Code: " + GetAll.ModuleCode +
                                          "\nModuleName: " + GetAll.ModuleName +
                                          "\nSemester Start: " + GetAll.Semesterweeks +
                                          "\nCredits: " + GetAll.Credits+
                                          "\nSelf Study Hours: " + GetAll.Weekly() +
                                          "\nStart Date :" + start +
                                          "\nEnd Date :" + end +
                                          "\nDaily Module Study Hours: " + GetAll.Studyhours +
                                          "\nRemainng Self Study Hours: " + GetAll.RemainingHours() +
                                      "\n~*~*~*~*~*~*~*~*~*~*~*~*~*~~*~*~*~*~~*~*~*~*~*~*~*~~*~*");

                   

                }
                Class2 connect = new Class2();
                connect.conn.Open();
   //sqlconnection

                SqlCommand cmd = new SqlCommand("insert into ModuleTable values (@Startdate, @Name, @Weeks, @Hours ,@SemsterWeeks , @EndDate , @HoursStudied , @ModuleCode)", connect.conn);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@Startdate", start);
                cmd.Parameters.AddWithValue("@Name", Namebx.Text);
                cmd.Parameters.AddWithValue("@Weeks", weeksbx.Text);
                cmd.Parameters.AddWithValue("@Hours", hoursbx.Text);
                cmd.Parameters.AddWithValue("@SemsterWeeks", semsterbx.Text);
                cmd.Parameters.AddWithValue("@EndDate", end);
                cmd.Parameters.AddWithValue("@HoursStudied", hoursbx1.Text);
                cmd.Parameters.AddWithValue("@ModuleCode", Codebx.Text);
                cmd.ExecuteNonQuery();
                connect.conn.Close();

                //clearbox
                Codebx.Clear();
                Namebx.Clear();
                weeksbx.Clear();
                Credits_.Clear();
                semsterbx.Clear();
                hoursbx.Clear();
              hoursbx1.Clear();

                


            }
            catch (SqlException ex)
            {


         
                Unsuccessful unsuccessful = new Unsuccessful();
                unsuccessful.ShowDialog();
                MessageBox.Show(ex.Message.ToString());
            }
        }
        //validate
        public void Validate()
        {
            
            
            
         
            {
                Codebx.BorderBrush = Brushes.Red;


            }

            if (String.IsNullOrEmpty(Namebx.Text))
            {
                Namebx.BorderBrush = Brushes.Red;


            }
            if (String.IsNullOrEmpty(Credits_.Text))
            {
                Credits_.BorderBrush = Brushes.Red;


            }
            if (String.IsNullOrEmpty(semsterbx.Text))
            {
                semsterbx.BorderBrush = Brushes.Red;


            }
            if (String.IsNullOrEmpty(hoursbx.Text))
            {
                hoursbx.BorderBrush = Brushes.Red;


            }
            if (String.IsNullOrEmpty(Codebx.Text))
            {
                hoursbx.BorderBrush = Brushes.Red;


            }

           



        }
    }
    }

