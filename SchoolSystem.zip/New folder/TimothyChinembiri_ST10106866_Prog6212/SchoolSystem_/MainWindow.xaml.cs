﻿using MaterialDesignThemes.Wpf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MaterialDesignThemes.Wpf;
using ClassLibrary;
using System.Data.SqlClient;
using System.Data;

namespace SchoolSystem_
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        //darkTheme
        public bool IsDarkTheme { get; set; }
        private readonly PaletteHelper paletteHelper = new PaletteHelper();
        private void ThemeToggle_Click(object sender, RoutedEventArgs e)
        {
            ITheme theme = paletteHelper.GetTheme();
            if (IsDarkTheme = theme.GetBaseTheme() == BaseTheme.Dark)
            {
                IsDarkTheme = false;
                theme.SetBaseTheme(Theme.Light);
            }
            else
            {
                IsDarkTheme = true;
                theme.SetBaseTheme(Theme.Dark);
            }
            paletteHelper.SetTheme(theme);
        }
        //exit button

        private void exitbtn_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);
            DragMove();
        }

        private void signinbtn_Click(object sender, RoutedEventArgs e)
        {
            Registration registration = new Registration();
            Close();
            registration.Show();

        }

        private void loginbtn_Click(object sender, RoutedEventArgs e)
        {
                try
            {
                Validate();
               
                    Class2 connect = new Class2();
                    connect.conn.Open();
                    String HashPassword = Class1.PasswordHashing(Passwordb.Password);
                    SqlCommand cmd = new SqlCommand("Select * From RegistrationTable Where Username = @Username AND Password = @Password", connect.conn);
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@Username", Usernameb.Text);
                    cmd.Parameters.AddWithValue("@Password", HashPassword);
                    Loading loading = new Loading();
                    Close();
                    loading.Show();
                
            }
            catch (SqlException ex)
            {
                Unsuccessful unsuccessful = new Unsuccessful();
                unsuccessful.ShowDialog();
                MessageBox.Show(ex.Message.ToString());
            }
           
        }
        //validate
        public void Validate()
        {
            if (String.IsNullOrEmpty(Usernameb.Text))
            {
                Usernameb.BorderBrush = Brushes.Red;


            }
           






        }
    }
}
