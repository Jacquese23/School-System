﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SchoolSystem_
{
    /// <summary>
    /// Interaction logic for Unsuccessful.xaml
    /// </summary>
    public partial class Unsuccessful : Window
    {
        public Unsuccessful()
        {
            InitializeComponent();
        }

        private void okbtn(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
        }

       
    }
}
