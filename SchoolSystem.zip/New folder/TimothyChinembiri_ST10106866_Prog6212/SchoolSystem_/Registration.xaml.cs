﻿using ClassLibrary;
using MaterialDesignThemes.Wpf;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SchoolSystem_
{
    /// <summary>
    /// Interaction logic for Registration.xaml
    /// </summary>
    public partial class Registration : Window
    {
        public Registration()
        {
            InitializeComponent();
        }
        //boolen method for darkthem
        public bool IsDarkTheme { get; set; }
        private readonly PaletteHelper paletteHelpers = new PaletteHelper();
        
      
        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);
            DragMove();
        }
  
        //Theme click method
        private void ThemeToggle_Click_1(object sender, RoutedEventArgs e)
        {

            ITheme theme = paletteHelpers.GetTheme();
            if (IsDarkTheme = theme.GetBaseTheme() == BaseTheme.Dark)
            {
                IsDarkTheme = false;
                theme.SetBaseTheme(Theme.Light);
            }
            else
            {
                IsDarkTheme = true;
                theme.SetBaseTheme(Theme.Dark);
            }
            paletteHelpers.SetTheme(theme);
        }
    
        //Exit click
        private void exitbtn_Click_1(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
        //Create method 
        private void createbtn_Click(object sender, RoutedEventArgs e)
        {

           //catch
            try
            {
                Validate();
               
                    Class2 connect = new Class2();
                    connect.conn.Open();
                    String HashPassword = Class1.PasswordHashing(Passwordb2.Password);
                    SqlCommand cmd = new SqlCommand("insert into RegistrationTable values (@Name, @Username, @Password)", connect.conn);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@Name", Name.Text);
                    cmd.Parameters.AddWithValue("@Username", Usernameb2.Text);
                    cmd.Parameters.AddWithValue("@Password", HashPassword);
                    cmd.ExecuteNonQuery();
                    connect.conn.Close();


                    Loading loading = new Loading();
                    Close();
                    loading.Show();
                
                
            }
            catch (SqlException ex)
            {
                Unsuccessful unsuccessful = new Unsuccessful();
                unsuccessful.ShowDialog();
                MessageBox.Show(ex.Message.ToString());
            }

        }
        //Validate method
        public void Validate()
        {
            if (String.IsNullOrEmpty(Name.Text))
            {
                Name.BorderBrush = Brushes.Red;


            }
            if (String.IsNullOrWhiteSpace(Usernameb2.Text))
            {
                Usernameb2.BorderBrush = Brushes.Red;

            }



          

           
        }
        //Sign up
        private void signupbtn_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Close();
        }
    }
}
