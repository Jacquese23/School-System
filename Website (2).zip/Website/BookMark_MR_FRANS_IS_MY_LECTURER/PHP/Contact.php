<?php

include 'ConfigurePage.php';

session_start();

$user_id = $_SESSION['userid'];

if(!isset($user_id)){
   header('location:Login.php');
}

if(isset($_POST['send'])){

   $name = mysqli_real_escape_string($connects, $_POST['name']);
   
   $email = mysqli_real_escape_string($connects, $_POST['email']);
   
   $number = $_POST['number'];
   $msg = mysqli_real_escape_string($connects, $_POST['message']);

   $select_message = mysqli_query($connects, "SELECT * FROM `message` WHERE name = '$name' AND email = '$email' AND number = '$number' AND
   message = '$msg'") or die('query failed');

   if(mysqli_num_rows($select_message) > 0){
	   
      $message[] = 'message sent already!';
   }else{
      mysqli_query($connects, "INSERT INTO `message`(userid, name, email, number, message) VALUES('$user_id', '$name', '$email', '$number', '$msg')") or die('query failed');
      $message[] = 'message sent successfully!';
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Contact</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

 
   <!--  css file link  -->
  <link rel="stylesheet"  type= "text/css" href="Style.css">


</head>
<body>
   
<?php include 'Header.php'; ?>

<div class="heading">
   <h3>Contact us</h3>
   <p> <a href="Home.php">Home</a> / Contact </p>
</div>

<section class="contact">

   <form action="" method="post">
      <h3>Say something!</h3>
      <input type="text" name="name" required placeholder="enter your name" class="box">
      <input type="email" name="email" required placeholder="enter your email" class="box">
      <input type="number" name="number" required placeholder="enter your number" class="box">
      <textarea name="message" class="box" placeholder="enter your message" id="" cols="30" rows="10"></textarea>
      <input type="submit" value="send message" name="send" class="btn">
   </form>

</section>








<?php include 'Footer.php'; ?>
<!--  js file link  -->
<script src="text/JS.js"></script>

</body>
</html>