<?php

$connects = mysqli_connect('localhost','root','','bookstore') or die('connection failed');

?>