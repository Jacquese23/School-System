<?php

include 'ConfigurePage.php';

session_start();

$user_id = $_SESSION['userid'];

if(!isset($user_id)){
   header('location:Login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>about</title>
   <!-- font cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!--  css file link  -->
  <link rel="stylesheet"  type= "text/css" href="Style.css">


</head>
<body>
   
<?php include 'Header.php'; ?>

<div class="heading">
   <h3>About us</h3>
   <p> <a href="home.php">Home</a> / About </p>
</div>

<section class="about">

   <div class="flex">

      <div class="image">
         <img src="images/about-img.jpg" alt="">
      </div>

      <div class="content">
         <h3>why choose us?</h3>
         <p>We Inspire Change.</p>
         <p>Books are merely more than books, they are an escape to from reality, and thats what we do best. We provide books that are high quailty yet affordable</p>
         <a href="contact.php" class="btn">Contact us</a>
      </div>

   </div>

</section>

<section class="reviews">

   <h1 class="title">Client's reviews</h1>

   <div class="box-container">

      <div class="box">
         <img src="imag/client1.jpg" alt="">
         <p> These Books are amazing. Keep Up the good work.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
             <i class="fas fa-star"></i>
         </div>
         <h3>Mike Brown</h3>
      </div>

      <div class="box">
           <img src="imag/client3.jpg" alt="">
         <p>My book is in a good condition <p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
         </div>
         <h3>john deo</h3>
      </div>

      <div class="box">
             <img src="imag/client4.jpg" alt="">
         <p>These books inspire change.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
       <i class="fas fa-star"></i>
         </div>
         <h3>Michelle Spark</h3>
      </div>

      <div class="box">
            <img src="imag/client5.jpg" alt="">
         <p>May you guys keep up the good work.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
             <i class="fas fa-star"></i>
         </div>
         <h3>Jane Loves</h3>
      </div>

      <div class="box">
            <img src="imag/client6.jpg" alt="">
         <p>These books are really in good condition</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
         </div>
         <h3>Kelly Smith</h3>
      </div>

      <div class="box">
             <img src="imag/client7.jpg" alt="">
         <p>BookMark is an amazing website</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
         </div>
         <h3>Luke Dennis</h3>
      </div>

   </div>

</section>

<section class="authors">

   <h1 class="title">Authors Memorabilia</h1>

   <div class="box-container">

      <div class="box">
         <img src="imag/author1.jpg" alt="">
         <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-linkedin"></a>
         </div>
         <h3>JK Rowlings </h3>
      </div>

      <div class="box">
         <img src="imag/author2.jpg" alt="">
         <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-linkedin"></a>
         </div>
         <h3>Patty Miches</h3>
      </div>

      <div class="box">
         <img src="imag/author3.png" alt="">
         <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-linkedin"></a>
         </div>
         <h3>Lyn Rose</h3>
      </div>

      <div class="box">
         <img src="imag/author4.jpg" alt="">
         <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-linkedin"></a>
         </div>
         <h3>Witney Greens</h3>
      </div>

      <div class="box">
         <img src="imag/author5.jpg" alt="">
         <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-linkedin"></a>
         </div>
         <h3>Abigal Martins</h3>
      </div>

      <div class="box">
         <img src="imag/author6.jpg" alt="">
         <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-linkedin"></a>
         </div>
         <h3>Tammy Muchin</h3>
      </div>

   </div>

</section>







<?php include 'Footer.php'; ?>

<!--  js file link  -->
<script src="text/JS.js"></script>

</body>
</html>