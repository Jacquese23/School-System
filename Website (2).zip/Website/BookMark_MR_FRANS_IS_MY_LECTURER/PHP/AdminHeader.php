<?php
if(isset($message)){
   foreach($message as $message){
      echo '
      <div class="message">
         <span>'.$message.'</span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>
      ';
   }
}
?>

<header class="header">

   <div class="flex">

      <a href="AdminPage.php" class="logo">Admin<span>Panel</span></a>

      <nav class="navbar">
         <a href="AdminPage.php">Home</a>
         <a href="AdminProducts.php">Products</a>
         <a href="AdminOrders.php">Orders</a>
         <a href="AdminUser.php">Users</a>
         <a href="AdminContact.php">Messages</a>
      </nav>

      <div class="icons">
         <div id="menu-btn" class="fas fa-bars"></div>
         <div id="user-btn" class="fas fa-user"></div>
      </div>

      <div class="account-box">
         <p>Username : <span><?php echo $_SESSION['adminname']; ?></span></p>
         <p>Email : <span><?php echo $_SESSION['adminemail']; ?></span></p>
         <a href="Logout.php" class="delete-btn">logout</a>
         <div>New <a href="Login.php">Login</a> | <a href="register.php">Register</a></div>
      </div>

   </div>

</header>