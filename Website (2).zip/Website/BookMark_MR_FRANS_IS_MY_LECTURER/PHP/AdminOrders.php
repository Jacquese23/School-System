<?php

include 'ConfigurePage.php';

session_start();

$admin_id = $_SESSION['adminid'];

if(!isset($admin_id)){
   header('location:Login.php');
}


if(isset($_POST['updateorder'])){

   $order_update_id = $_POST['orderid'];
   $update_payment = $_POST['updatepayment'];
   mysqli_query($conn, "UPDATE `orders` SET paymentstatus = '$update_payment' WHERE id = '$order_update_id'") or die('query failed');
   $message[] = 'payment status has been updated!';

}

if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];
   mysqli_query($connects, "DELETE FROM `orders` WHERE id = '$delete_id'") or die('query failed');
   header('location:AdminOrders.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Orders</title>

   <!-- font awesome cdn link  -->
     <!-- font cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
  <link rel="stylesheet"  type= "text/css" href="Admincss.css">

</head>
<body>
   
<?php include 'AdminHeader.php'; ?>

<section class="orders">

   <h1 class="title">Placed orders</h1>

   <div class="box-container">
      <?php
      $select_orders = mysqli_query($connects, "SELECT * FROM `orders`") or die('query failed');
      if(mysqli_num_rows($select_orders) > 0){
         while($fetch_orders = mysqli_fetch_assoc($select_orders)){
      ?>
      <div class="box">
         <p> User id : <span><?php echo $fetch_orders['userid']; ?></span> </p>
         <p> Placed on : <span><?php echo $fetch_orders['placedon']; ?></span> </p>
         <p> Name : <span><?php echo $fetch_orders['name']; ?></span> </p>
         <p> Number : <span><?php echo $fetch_orders['number']; ?></span> </p>
         <p> Email : <span><?php echo $fetch_orders['email']; ?></span> </p>
         <p> Address : <span><?php echo $fetch_orders['address']; ?></span> </p>
         <p> Total products : <span><?php echo $fetch_orders['totalproducts']; ?></span> </p>
         <p> Total price : <span>R<?php echo $fetch_orders['totalprice']; ?>/-</span> </p>
         <p> Payment method : <span><?php echo $fetch_orders['method']; ?></span> </p>
         <form action="" method="post">
            <input type="hidden" name="orderid" value="<?php echo $fetch_orders['id']; ?>">
            <select name="updatepayment">
               <option value="" selected disabled><?php echo $fetch_orders['paymentstatus']; ?></option>
               <option value="pending">Pending</option>
               <option value="completed">Completed</option>
            </select>
            <input type="submit" value="update" name="updateorder" class="option-btn">
            <a href="AdminOrders.php?delete=<?php echo $fetch_orders['id']; ?>" onclick="Return confirm('delete this order?');"
			class="delete-btn">delete</a>
         </form>
      </div>
      <?php
         }
      }else{
         echo '<p class="empty">no orders placed yet!</p>';
      }
      ?>
   </div>

</section>









<!--  js file link  -->
<script src="text/AdminJS.js"></script>

</body>
</html>