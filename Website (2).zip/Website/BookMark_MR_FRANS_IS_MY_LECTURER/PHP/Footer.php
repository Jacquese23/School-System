<section class="footer">

   <div class="box-container">

      <div class="box">
	  
         <h3>Quick links</h3>
         <a href="Home.php">Home</a>
		 
         <a href="About.php">About</a>
         <a href="Shop.php">Shop</a>
		 
         <a href="Contact.php">Contact</a>
      </div>

      <div class="box">
         <h3>Extra links</h3>
         <a href="Login.php">Login</a>
		 
         <a href="Register.php">Register</a>
         <a href="Cart.php">Cart</a>
		 
         <a href="Orders.php">Orders</a>
      </div>

      <div class="box">
         <h3>Contact info</h3>
         <p> <i class="fas fa-phone"></i> +27 64 199 6069 </p>
         <p> <i class="fas fa-phone"></i> +011-232-3432 </p>
		 
         <p> <i class="fas fa-envelope"></i> rosebank@gmail.com </p>
         <p> <i class="fas fa-map-marker-alt"></i> South Africa, Johannesburg - 2407 </p>
      </div>

      <div class="box">
         <h3>Follow us</h3>
         <a href="#"> <i class="fab fa-facebook-f"></i> facebook </a>
		 
         <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
		 
         <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
         
      </div>

   </div>

   <p class="credit"> &copy; Copyright  @ <?php echo date('Y'); ?> By <span>Timothy Chinembiri</span> </p>

</section>